
import xloil as xlo

@xlo.func
def Greeting(who):
    return "Hello  " + who
	
@xlo.func
def Adder(x, y):
    return x + y