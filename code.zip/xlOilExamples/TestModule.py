import xloil as xlo

@xlo.func
def pyTestLoadMod():
    return "Great Success!"

