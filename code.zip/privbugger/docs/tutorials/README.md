In this folder we place the notebooks with examples and tutorials. After placing a notebook (e.g., `notebook.ipynb`) you need to modify the file `../index.rst` by adding a new line `tutorials/notebook.ipynb` so that it appears in the left menu of the documentation.

**The only constraint is that notebooks should have at most one level 1 header**, i.e., the header starting with exactly one (#).
