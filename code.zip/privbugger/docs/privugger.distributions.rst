Privugger Distributions
=====================

continuous module
----------------------------------------------

.. automodule:: privugger.distributions.continuous
   :members:
   :undoc-members:
   :show-inheritance:

discrete module
----------------------------------------------

.. automodule:: privugger.distributions.discrete
   :members:
   :undoc-members:
   :show-inheritance:      

