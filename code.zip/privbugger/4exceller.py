import subprocess
import os
from datetime import datetime
import time
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt
import privugger as pv
import json
import pymc3 as pm
import arviz as az
import re

#os.system('ls -l')
#conda_env = "conda activate pymc_clone"
#path = "cd C:\\Users\\andre\\office\\privbugger"
#run = "python 5runner.py"
#os.system(conda_env + ";" + path + ";" + run)
#elevate user privelege.

#process = subprocess.Popen(["/Users"],
#                     stdout=subprocess.PIPE, 
#                     stderr=subprocess.PIPE)
#stdout, stderr = process.communicate()
#stdout, stderr

#def avg(*items):
#    l = []
#    for i in items:
#        l.append(i.sum() / (i.size)) 
#    return l

def avg2(i):
    return (i.sum()) / (i.size)

def kl_divergence(p, q):
    return np.sum(np.where(p != 0, p * np.log(p / q), 0))

def get_dist(text,name,mu=1,std=1,num_elements=100):

    x = re.search("(.*)\((.*)\)", text.lower())
    t = x.group(1)  
    extra = x.group(2)

    if(t == 'normal'):
	    return pv.Normal(name,mu=mu,std=std,num_elements=num_elements)
    if(t == 'exponential'):
	    a1 = pv.Exponential(name,mu=mu,std=std,num_elements=num_elements)
    if(t == 'beta'):
        a1 = pv.Beta(name,a=mu,b=std,num_elements=num_elements)
    if(t == 'uniform'):
        a1 = pv.Uniform(name,mu=mu,std=std,num_elements=num_elements)
    if(t == 'bernoulli'):
	    a1 = pv.Bernoulli(name,mu=mu,std=std,num_elements=num_elements)
    if(t == 'binomial'):
	    a1 = pv.Binomial(name,mu=mu,std=std,num_elements=num_elements)
    #if(t == 'categorical'):
	#    a1 = pv.Categorical(name,mu=mu,std=std,num_elements=num_elements)
    #if(t == 'constant'):
	#    a1 = pv.Constant(name,mu=mu,std=std,num_elements=num_elements)
    #if(t == 'discreteuniform'):
	#    a1 = pv.DiscreteUniform(name,mu=mu,std=std,num_elements=num_elements)
    if(t == 'Geometric'):
	    a1 = pv.Geometric(name,mu=mu,std=std,num_elements=num_elements)
    return a1

def divergence(header,data,distributions):
    dists = []
    #to do get mean and variance
    for idx,i in enumerate(distributions):
            dists.append(get_dist(i,header[idx]))
    #ages2 = pv.Normal('ages',mu=35,std=2,num_elements=100)
    #zipcode = pv.Normal('zipcode',mu=35,std=2,num_elements=100)
    # input spec
    # create a privugger dataset
    ds = pv.Dataset(input_specs=dists)

    program = pv.Program('output',
                         dataset=ds,
                         output_type=pv.Float,
                         function=avg2)

    trace   = pv.infer(program,
                       cores=4,
                       draws=10_000,
                       method='pymc3')
    
    attrs = header #['ages','zipcode']

    trace_attr = lambda attr : np.concatenate(trace.posterior[attr],axis=0)

    y=[[pv.mi_sklearn([trace_attr(attr)[:,0], trace_attr('output')[:]],
                  n_neigh=40,input_inferencedata=False)[0]
       for attr in attrs] for i in range(0,100)]

    
    outputs = np.array(trace.posterior.output).flatten()

    create_plot(y,attrs)

def create_plot(y,attrs):
    plt.boxplot(np.array(y),attrs,
                showmeans=False, showfliers=False, patch_artist=True, vert=True)
    plt.ylabel('$I(attr_0;income)$')
    plt.title("Mutual information between attributes")
    plt.savefig('figure.png')

def mutual_information(header,data,distr,idx):
    print(header)
    print(distr)
    dist = get_dist(distr,header)

    ds = pv.Dataset(input_specs=[dist])

    program = pv.Program('output_' + str(header),
                         dataset=ds,
                         output_type=pv.Float,
                         function=avg2)

    trace   = pv.infer(program,
                       cores=4,
                       draws=10_000,
                       method='pymc3')

    model = pv.infer(program,return_model=True)
    posterior_age = trace.posterior[header][:,:,0].values.flatten()
    prior_alice_age = pm.sample_prior_predictive(model=model, samples=posterior_age.size)[header][:,0]
#    print(prior_alice_age)
#    print(posterior_age)
    plt.hist(prior_alice_age,label='Prior',color='orange')
    plt.hist(posterior_age,label='Posterior')
    plt.title('Prior vs Posterior attacker knowledge ' + header)
    plt.legend(loc='best')
    plt.savefig('figure_' + header + '.png')
    


def prior_posterior(header,data,distribution):
    mutual = []
    for idx, i in enumerate(header):
        mutual.append(mutual_information(header[idx],data[idx],distribution[idx],idx))

def run_request(json_object):
    print('loaded')
    request = json_object['request']
    header = json_object['header'][0]
    data = json_object['data']
    distribution = json_object['distribution'][0]
    if(request == 'sum_divergence'):
        divergence(header,data,distribution)
    if(request == 'sum_prior_postierior'):
        prior_posterior(header,data,distribution)

def Check_Req():
    now = datetime.now().time()
 
    request_loc = "C:/Users/andre/office/sample.json"
    # Opening JSON file
    with open(request_loc, 'r') as openfile:
 
        # Reading from json file
        json_object = json.load(openfile)   
        if 'header' in json_object:
            run_request(json_object)





            with open("response.txt", "w") as f:
                f.write('Done')

        #print(rcontent,end ="")
    #clear for new requests
    #open(request_loc, 'w').close()

    time.sleep(2)

open('response.txt', 'w').close()

print('Initialized')
while True:
    Check_Req()
#with open("request.txt", "w") as f:
#    f.write("hel2lo")

#with open("request.txt", "r") as f:
#    print(f.readlines())

