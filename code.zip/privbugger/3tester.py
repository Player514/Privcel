import json
import numpy as np


request_loc = "C:/Users/andre/office/sample.json"

with open(request_loc, 'r') as openfile:
    json_object = json.load(openfile)   

    request = np.array(json_object['request'])
    header = np.array(json_object['header'][0])
    data = np.array(json_object['data'])
    distribution = np.array(json_object['distribution'][0])

    print(distribution)