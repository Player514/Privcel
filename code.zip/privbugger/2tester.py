# disable FutureWarnings to have a cleaner output
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# move to previouse directory to access the privugger code
import os, sys
sys.path.append(os.path.join("../../"))

# external libraries used in the notebook
import numpy as np
#import cm as az
#import matplotlib.pyplot as plt

# privugger library
import privugger as pv


# external libraries used in the notebook
import numpy as np
import arviz as az
import matplotlib.pyplot as plt




def avg(ages):
    return (ages.sum()) / (ages.size)
	
	
ages = pv.Normal('ages',mu=35,std=2,num_elements=100)
# input spec

# create a privugger dataset
ds = pv.Dataset(input_specs=[ages])


program = pv.Program('output',
                     dataset=ds,
                     output_type=pv.Float,
                     function=avg)
					 

trace   = pv.infer(program,
                   cores=4,
                   draws=10_000,
                   method='pymc3')	

print(trace.posterior['output'])



def runtest(range):
	#to getRangevalues
	
	a1 = pv.Normal('ages',mu=35,std=2,num_elements=100)
	a2 = pv.Exponential('ages',mu=35,std=2,num_elements=100)
	# input spec

	# create a privugger dataset
	ds = pv.Dataset(input_specs=[ages])

	program = pv.Program('output',
						 dataset=ds,
						 output_type=pv.Float,
						 function=avg)
						 
	
	trace   = pv.infer(program,
					   cores=4,
					   draws=1_000,
					   method='pymc3')	
					   
	az.hdi(posterior_alice_age,hdi_prob=.95)
	
	

def getpv(t,mu,std,num_elements=100):
	t = t.lower()
	if(t == 'normal'):
		a1 = pv.Normal('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'exponential'):
		a1 = pv.Exponential('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'beta'):
		a1 = pv.Beta('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'uniform'):
		a1 = pv.Uniform('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'bernoulli'):
		a1 = pv.Bernoulli('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'binomial'):
		a1 = pv.Binomial('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'categorical'):
		a1 = pv.Categorical('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'constant'):
		a1 = pv.Constant('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'discreteuniform'):
		a1 = pv.DiscreteUniform('ages',mu=mu,std=std,num_elements=num_elements)
	if(t == 'Geometric'):
		a1 = pv.Geometric('ages',mu=mu,std=std,num_elements=num_elements)
		
		
	#default case
		
	#DiscreteUniform
	#Categorical
	


	
	