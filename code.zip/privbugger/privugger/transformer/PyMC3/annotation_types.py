    



class Int():
    a_type = "int"
    def __init__(self):
        pass

class Float():
    a_type = "float"
    def __init__(self):
        pass


class List():
    a_type = None
    def __init__(self):
        pass



class Tuple():
    length = None
    a_type = []
    def __init__(self):
        pass




