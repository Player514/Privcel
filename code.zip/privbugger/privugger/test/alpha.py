def alpha(age):
    return (age.sum()) / (age.size)
        
