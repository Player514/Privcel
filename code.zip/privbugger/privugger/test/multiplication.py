def name(age, height):
    return age*height