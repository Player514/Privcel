def name(age):
    return age