import subprocess
import os
from datetime import datetime
import time

#os.system('ls -l')
#conda_env = "conda activate pymc_clone"
#path = "cd C:\\Users\\andre\\office\\privbugger"
#run = "python 5runner.py"

#elevate user privelege.


#process = subprocess.Popen(["/Users"],
#                     stdout=subprocess.PIPE, 
#                     stderr=subprocess.PIPE)
#stdout, stderr = process.communicate()
#stdout, stderr

def Check_Req():
    now = datetime.now().time()

    with open("request.txt", "r") as f:

        rcontent = f.readline()
        #Do stuff

        with open("response.txt", "w") as f:
            f.write(rcontent)

        print(rcontent)
        #print(rcontent,end ="")
    #clear for new requests
    open('request.txt', 'w').close()

    time.sleep(2)


open('response.txt', 'w').close()

while True:
    Check_Req()
#with open("request.txt", "w") as f:
#    f.write("hel2lo")

#with open("request.txt", "r") as f:
#    print(f.readlines())
